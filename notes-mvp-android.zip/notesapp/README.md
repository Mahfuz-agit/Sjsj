# Notes MVP — Android Scaffold

Native Kotlin + Jetpack Compose, per the agreed tech decision (speed/typing
latency prioritized over cross-platform code sharing).

## What's implemented

- **Local-first storage**: Room over SQLite (`data/local`). Single source of
  truth, no server dependency, matches the "server/sync excluded for v1"
  scope decision.
- **Repository boundary** (`data/repository/NoteRepository.kt`): all
  UI/ViewModel code talks to this, never to the DAO directly. This is where
  v2 sync (Yjs/CRDT) gets added later without touching any screen.
- **Block-based editor**: flat block list (paragraph, heading, checkbox,
  list item, code) — no nested tree, to avoid the typing-lag failure mode
  called out in the PRD. Backed by `util/Block.kt`.
- **"/" slash command menu**: inline block-type picker, one interaction
  pattern reused everywhere (`ui/components/SlashMenu.kt`).
- **Instant, as-typed client-side search**: SQLite LIKE query for MVP scale
  (`NoteDao.search`), swappable for FTS4 later if note counts grow.
- **Virtualized rendering**: `LazyColumn` in `EditorScreen.kt` — only
  on-screen blocks compose.
- **Zero-friction onboarding**: first launch creates a pre-filled example
  document (`util/exampleDocumentBlocks()`), no sign-up, no blank page.
- **Debounced autosave + subtle save indicator**: keystrokes update UI state
  instantly; disk writes debounced 400ms; a "Saved" label fades in/out over
  ~1s, never blocking (`EditorViewModel.kt`, `SaveIndicator.kt`).
- **Collapsible doc list**: hidden by default, reached via a single menu
  icon, not a persistent sidebar (`DocListScreen.kt`).
- **Light theme only**, deliberately — no dark mode variant yet.

## What's intentionally NOT implemented (matches current MVP scope)

- No server, no remote database, no network calls anywhere in this codebase.
- No CRDT/Yjs sync, no real-time collaboration.
- No offline edit queue (nothing to queue against yet).
- No multi-language / localization — single hardcoded language (English).
- No settings screen.
- No dark mode.

## Known gaps in this scaffold (things you'll hit immediately)

- **gradle-wrapper.jar is missing.** This container has no network access,
  so the wrapper binary couldn't be downloaded. Open the project in Android
  Studio directly (it will regenerate the wrapper), or run `gradle wrapper`
  locally once you have Gradle installed.
- **No app icon design pass** — the launcher icon is a placeholder single
  glyph (page shape), functional but not a final asset.
- **Editor is a foundation, not a finished rich text engine.** Formatting is
  limited to the five block types listed above. No inline bold/italic, no
  drag-to-reorder blocks, no indent/nesting yet. These are straightforward
  additions on top of the existing `Block` model but aren't built yet.
- **No tests written yet** (unit tests for `NoteRepository`, instrumented
  tests for the DAO would be the first additions).
- **No ProGuard/R8 rules reviewed** — minification is off for this build
  type; fine for MVP testing, revisit before a release build.

## Architecture at a glance

```
MainActivity (NavHost: editor / editor/{id} / newEditor / docList)
        │
        ▼
  EditorViewModel / DocListViewModel  (ui/viewmodel)
        │
        ▼
  NoteRepository                      (data/repository)
        │
        ▼
  NoteDao → AppDatabase (Room/SQLite) (data/local)
```

## Building

1. Open this folder in Android Studio (Koala or newer recommended).
2. Let Gradle sync — it will fetch the wrapper and dependencies.
3. Run on an emulator or device, min SDK 26 (Android 8.0).

## Suggested next steps, in priority order

1. Get it building and running as-is; confirm the debounced autosave feels
   instant on a real device, not just the emulator.
2. Add inline formatting (bold/italic) to the block text field.
3. Add block reordering (drag handle) — currently blocks are append-only
   after the block that triggered "/".
4. Write the first unit tests around `NoteRepository` before adding more
   features on top of it.
5. Revisit dark mode and localization only when explicitly re-scoped.
