package com.notesapp.mvp.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.notesapp.mvp.ui.theme.AppColors
import com.notesapp.mvp.util.BlockType

private data class SlashOption(val label: String, val type: BlockType)

private val options = listOf(
    SlashOption("Text", BlockType.PARAGRAPH),
    SlashOption("Heading", BlockType.HEADING),
    SlashOption("Checklist", BlockType.CHECKBOX),
    SlashOption("List item", BlockType.LIST_ITEM),
    SlashOption("Code", BlockType.CODE),
)

/**
 * Appears inline, directly below the block where "/" was typed — no modal,
 * no separate screen. This is the single, reused pattern for inserting any
 * block type (Consistency principle: one interaction, works everywhere).
 */
@Composable
fun SlashMenu(onSelect: (BlockType) -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AppColors.surfaceRecede)
            .padding(vertical = 4.dp)
    ) {
        options.forEach { option ->
            Text(
                text = option.label,
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.content,
                modifier = Modifier
                    .clickable { onSelect(option.type) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}
