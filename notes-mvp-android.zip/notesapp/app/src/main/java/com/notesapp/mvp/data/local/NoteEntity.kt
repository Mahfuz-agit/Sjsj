package com.notesapp.mvp.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Local-first storage: this table is the single source of truth for MVP.
 * blocksJson stores the serialized List<Block> from util.Block.
 *
 * Deliberately no "syncStatus" or "remoteId" column yet — sync is out of
 * scope for this MVP per the PRD. When sync (v2) is added, prefer adding
 * new columns via migration rather than reshaping this table, so existing
 * local data isn't disturbed.
 */
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val title: String,
    val blocksJson: String,
    val createdAt: Long,
    val updatedAt: Long,
    val lastOpenedAt: Long
)
