package com.notesapp.mvp.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.notesapp.mvp.ui.components.BlockItem
import com.notesapp.mvp.ui.components.SaveIndicator
import com.notesapp.mvp.ui.components.SlashMenu
import com.notesapp.mvp.ui.theme.AppColors
import com.notesapp.mvp.ui.viewmodel.EditorViewModel

/**
 * Deliberately minimal chrome: title field, block list, corner save
 * indicator. No persistent toolbar (Deference / Restraint principle — the
 * document is the entire screen until the person asks for something else).
 *
 * LazyColumn gives virtualized rendering "for free" — only on-screen blocks
 * compose, per the PRD's virtualized rendering requirement for large docs.
 */
@Composable
fun EditorScreen(viewModel: EditorViewModel, onOpenDocList: () -> Unit) {
    val uiState by viewModel.uiState.collectAsState()
    var slashMenuForBlockId by remember { mutableStateOf<String?>(null) }

    Surface(color = AppColors.surface, modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize()) {
            val note = uiState.note

            if (!uiState.isLoading && note != null) {
                Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {

                    // Sidebar trigger only — no persistent sidebar, no title
                    // bar chrome. Collapsed by default per UI/UX decision;
                    // this is the single, small affordance to reach it.
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Icon(
                            imageVector = Icons.Filled.Menu,
                            contentDescription = "All notes",
                            tint = AppColors.contentSecondary,
                            modifier = Modifier
                                .clickable { onOpenDocList() }
                                .padding(bottom = 12.dp)
                        )
                    }

                    BasicTextField(
                        value = note.title,
                        onValueChange = viewModel::updateTitle,
                        textStyle = MaterialTheme.typography.headlineLarge.copy(color = AppColors.content),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(note.blocks, key = { it.id }) { block ->
                            Column {
                                BlockItem(
                                    block = block,
                                    onTextChange = { text -> viewModel.updateBlockText(block.id, text) },
                                    onSlashTriggered = { slashMenuForBlockId = block.id },
                                    onCheckedChange = { viewModel.toggleCheckbox(block.id) }
                                )
                                if (slashMenuForBlockId == block.id) {
                                    SlashMenu(onSelect = { type ->
                                        viewModel.insertBlockAfter(block.id, type)
                                        slashMenuForBlockId = null
                                    })
                                }
                            }
                        }
                    }
                }
            }

            SaveIndicator(
                state = uiState.saveState,
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            )
        }
    }
}
