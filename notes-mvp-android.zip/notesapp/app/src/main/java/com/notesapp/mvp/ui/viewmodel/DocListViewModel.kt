package com.notesapp.mvp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notesapp.mvp.data.local.NoteEntity
import com.notesapp.mvp.data.repository.NoteRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn

class DocListViewModel(private val repository: NoteRepository) : ViewModel() {

    private val query = MutableStateFlow("")

    val notes: StateFlow<List<NoteEntity>> = query
        .flatMapLatest { q ->
            if (q.isBlank()) repository.observeAll() else repository.search(q)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onSearchQueryChanged(newQuery: String) {
        query.value = newQuery
    }
}
