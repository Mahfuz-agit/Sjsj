package com.notesapp.mvp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.notesapp.mvp.data.local.AppDatabase
import com.notesapp.mvp.data.repository.NoteRepository
import com.notesapp.mvp.ui.screens.DocListScreen
import com.notesapp.mvp.ui.screens.EditorScreen
import com.notesapp.mvp.ui.theme.NotesMvpTheme
import com.notesapp.mvp.ui.viewmodel.DocListViewModel
import com.notesapp.mvp.ui.viewmodel.EditorViewModel
import com.notesapp.mvp.ui.viewmodel.ViewModelFactory

private const val ROUTE_EDITOR = "editor"
private const val ROUTE_EDITOR_WITH_ID = "editor/{noteId}"
// Deliberately not "editor/new" — that would collide with the
// "editor/{noteId}" pattern match in Navigation Compose's route parser.
private const val ROUTE_EDITOR_NEW = "newEditor"
private const val ROUTE_DOC_LIST = "docList"

class MainActivity : ComponentActivity() {

    // Single repository instance for the process — local-first, no DI
    // framework needed yet at this scale. Revisit if the app grows.
    private lateinit var repository: NoteRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = AppDatabase.getInstance(applicationContext)
        repository = NoteRepository(db.noteDao())
        val factory = ViewModelFactory(repository)

        setContent {
            NotesMvpTheme {
                val navController = rememberNavController()
                AppNavHost(navController = navController, factory = factory)
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun AppNavHost(navController: NavHostController, factory: ViewModelFactory) {
    NavHost(navController = navController, startDestination = ROUTE_EDITOR) {

        // Default: opens the most recently opened note directly.
        // Zero navigation on relaunch, per onboarding flow decision.
        composable(ROUTE_EDITOR) {
            val viewModel: EditorViewModel = viewModel(factory = factory)
            androidx.compose.runtime.LaunchedEffect(Unit) { viewModel.loadInitial() }
            EditorScreen(
                viewModel = viewModel,
                onOpenDocList = { navController.navigate(ROUTE_DOC_LIST) }
            )
        }

        composable(ROUTE_EDITOR_WITH_ID) { backStackEntry ->
            val noteId = backStackEntry.arguments?.getString("noteId") ?: return@composable
            val viewModel: EditorViewModel = viewModel(factory = factory)
            androidx.compose.runtime.LaunchedEffect(noteId) { viewModel.loadNote(noteId) }
            EditorScreen(
                viewModel = viewModel,
                onOpenDocList = { navController.navigate(ROUTE_DOC_LIST) }
            )
        }

        composable(ROUTE_EDITOR_NEW) {
            val viewModel: EditorViewModel = viewModel(factory = factory)
            androidx.compose.runtime.LaunchedEffect(Unit) { viewModel.createAndLoadNew() }
            EditorScreen(
                viewModel = viewModel,
                onOpenDocList = { navController.navigate(ROUTE_DOC_LIST) }
            )
        }

        composable(ROUTE_DOC_LIST) {
            val viewModel: DocListViewModel = viewModel(factory = factory)
            DocListScreen(
                viewModel = viewModel,
                onSelectNote = { id ->
                    navController.navigate("editor/$id") {
                        popUpTo(ROUTE_EDITOR) { inclusive = false }
                    }
                },
                onCreateNote = {
                    navController.navigate(ROUTE_EDITOR_NEW) {
                        popUpTo(ROUTE_EDITOR) { inclusive = false }
                    }
                }
            )
        }
    }
}
