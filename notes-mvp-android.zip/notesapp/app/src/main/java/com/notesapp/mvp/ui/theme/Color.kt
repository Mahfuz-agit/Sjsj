package com.notesapp.mvp.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Semantic color roles, not raw component colors. This is the transferable
 * HIG idea (name colors by purpose, not appearance) applied to our own,
 * non-Apple palette. Light mode only for MVP — see PRD scope decision.
 */
object AppColors {
    val surface = Color(0xFFFFFFFF)
    val surfaceRecede = Color(0xFFF7F6F4)      // sidebar, toolbars — deliberately recede
    val content = Color(0xFF1C1C1E)             // primary text, highest contrast
    val contentSecondary = Color(0xFF6E6E73)    // metadata, timestamps, placeholders
    val accent = Color(0xFF2F6FED)              // single accent color, used sparingly
    val divider = Color(0xFFE5E4E1)
    val warning = Color(0xFFC0392B)
    val checkboxDone = Color(0xFF8E8E93)
}
