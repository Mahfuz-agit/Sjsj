package com.notesapp.mvp.util

import kotlinx.serialization.Serializable

/**
 * Minimal block model for the MVP editor.
 *
 * Design note: this is intentionally flat (no nested children) to avoid the
 * "heavy nested block architecture" problem called out in the PRD as a cause
 * of typing lag in Notion-like editors. Nesting/indent can be added later as
 * an `indentLevel: Int` on the block rather than a tree structure, which keeps
 * the render path (LazyColumn of blocks) simple and fast.
 */
@Serializable
data class Block(
    val id: String,
    val type: BlockType,
    val text: String = "",
    val checked: Boolean = false // only meaningful for BlockType.CHECKBOX
)

@Serializable
enum class BlockType {
    PARAGRAPH,
    HEADING,
    LIST_ITEM,
    CHECKBOX,
    CODE
}

/** The document a brand-new user sees. No blank page, no separate tutorial. */
fun exampleDocumentBlocks(): List<Block> = listOf(
    Block(id = "b1", type = BlockType.HEADING, text = "Welcome"),
    Block(id = "b2", type = BlockType.PARAGRAPH, text = "This is your first note. Start typing anywhere."),
    Block(id = "b3", type = BlockType.PARAGRAPH, text = "Type \"/\" at the start of a line to insert a heading, checklist, or code block."),
    Block(id = "b4", type = BlockType.CHECKBOX, text = "Try checking this off", checked = false),
    Block(id = "b5", type = BlockType.LIST_ITEM, text = "Everything here saves automatically, offline"),
)
