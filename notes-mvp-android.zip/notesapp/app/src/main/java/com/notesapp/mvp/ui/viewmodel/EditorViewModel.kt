package com.notesapp.mvp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notesapp.mvp.data.repository.Note
import com.notesapp.mvp.data.repository.NoteRepository
import com.notesapp.mvp.util.Block
import com.notesapp.mvp.util.BlockType
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class SaveState { IDLE, SAVING, SAVED }

data class EditorUiState(
    val note: Note? = null,
    val saveState: SaveState = SaveState.IDLE,
    val isLoading: Boolean = true
)

/**
 * Debounce window before writing to disk. Keystrokes update in-memory state
 * instantly (this is what makes typing feel instant); persistence is
 * debounced so we're not hitting SQLite on every character.
 */
private const val AUTOSAVE_DEBOUNCE_MS = 400L
private const val SAVE_INDICATOR_VISIBLE_MS = 1000L

class EditorViewModel(private val repository: NoteRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private var saveJob: Job? = null
    private var indicatorJob: Job? = null

    fun loadInitial() {
        viewModelScope.launch {
            val note = repository.getOrCreateInitialNote()
            repository.markOpened(note.id)
            _uiState.value = EditorUiState(note = note, isLoading = false)
        }
    }

    fun createAndLoadNew() {
        viewModelScope.launch {
            val note = repository.createNote()
            _uiState.value = EditorUiState(note = note, isLoading = false)
        }
    }

    fun loadNote(id: String) {
        viewModelScope.launch {
            val note = repository.getById(id) ?: return@launch
            repository.markOpened(id)
            _uiState.value = EditorUiState(note = note, isLoading = false)
        }
    }

    fun updateTitle(title: String) {
        val current = _uiState.value.note ?: return
        _uiState.value = _uiState.value.copy(note = current.copy(title = title))
        scheduleSave()
    }

    fun updateBlockText(blockId: String, text: String) {
        val current = _uiState.value.note ?: return
        val updatedBlocks = current.blocks.map { if (it.id == blockId) it.copy(text = text) else it }
        _uiState.value = _uiState.value.copy(note = current.copy(blocks = updatedBlocks))
        scheduleSave()
    }

    fun toggleCheckbox(blockId: String) {
        val current = _uiState.value.note ?: return
        val updatedBlocks = current.blocks.map {
            if (it.id == blockId) it.copy(checked = !it.checked) else it
        }
        _uiState.value = _uiState.value.copy(note = current.copy(blocks = updatedBlocks))
        scheduleSave()
    }

    /** Inserts a new block after the given one — backs the "/" command menu. */
    fun insertBlockAfter(afterBlockId: String, type: BlockType) {
        val current = _uiState.value.note ?: return
        val index = current.blocks.indexOfFirst { it.id == afterBlockId }
        if (index == -1) return
        val newBlock = Block(id = UUID.randomUUID().toString(), type = type)
        val updated = current.blocks.toMutableList().apply { add(index + 1, newBlock) }
        _uiState.value = _uiState.value.copy(note = current.copy(blocks = updated))
        scheduleSave()
    }

    fun deleteBlock(blockId: String) {
        val current = _uiState.value.note ?: return
        if (current.blocks.size <= 1) return // always keep at least one block
        val updated = current.blocks.filterNot { it.id == blockId }
        _uiState.value = _uiState.value.copy(note = current.copy(blocks = updated))
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(AUTOSAVE_DEBOUNCE_MS)
            val note = _uiState.value.note ?: return@launch
            _uiState.value = _uiState.value.copy(saveState = SaveState.SAVING)
            repository.save(note)
            _uiState.value = _uiState.value.copy(saveState = SaveState.SAVED)

            indicatorJob?.cancel()
            indicatorJob = viewModelScope.launch {
                delay(SAVE_INDICATOR_VISIBLE_MS)
                _uiState.value = _uiState.value.copy(saveState = SaveState.IDLE)
            }
        }
    }
}
