package com.notesapp.mvp.data.repository

import com.notesapp.mvp.data.local.NoteDao
import com.notesapp.mvp.data.local.NoteEntity
import com.notesapp.mvp.util.Block
import com.notesapp.mvp.util.exampleDocumentBlocks
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.util.UUID

data class Note(
    val id: String,
    val title: String,
    val blocks: List<Block>,
    val createdAt: Long,
    val updatedAt: Long,
    val lastOpenedAt: Long
)

/**
 * Single access point for note data. UI and ViewModels talk to this, never
 * to NoteDao directly. This boundary is where v2 sync gets added (e.g.
 * wrapping writes in a Yjs update + queuing them for a WebSocket relay)
 * without requiring changes to any Compose screen or ViewModel.
 */
class NoteRepository(private val dao: NoteDao) {

    private val json = Json { ignoreUnknownKeys = true }

    fun observeAll(): Flow<List<NoteEntity>> = dao.getAll()

    fun search(query: String): Flow<List<NoteEntity>> = dao.search(query)

    suspend fun getOrCreateInitialNote(): Note {
        val existing = dao.getMostRecentlyOpened()
        if (existing != null) return existing.toNote()

        // First-ever launch: create the pre-filled example document.
        // Zero friction onboarding — no sign-up, no blank page.
        val now = System.currentTimeMillis()
        val note = Note(
            id = UUID.randomUUID().toString(),
            title = "Welcome",
            blocks = exampleDocumentBlocks(),
            createdAt = now,
            updatedAt = now,
            lastOpenedAt = now
        )
        dao.insert(note.toEntity(json))
        return note
    }

    suspend fun getById(id: String): Note? = dao.getById(id)?.toNote()

    suspend fun save(note: Note) {
        val updated = note.copy(updatedAt = System.currentTimeMillis())
        dao.update(updated.toEntity(json))
    }

    suspend fun markOpened(id: String) {
        val note = dao.getById(id) ?: return
        dao.update(note.copy(lastOpenedAt = System.currentTimeMillis()))
    }

    suspend fun createNote(): Note {
        val now = System.currentTimeMillis()
        val note = Note(
            id = UUID.randomUUID().toString(),
            title = "",
            blocks = emptyList(),
            createdAt = now,
            updatedAt = now,
            lastOpenedAt = now
        )
        dao.insert(note.toEntity(json))
        return note
    }

    suspend fun delete(id: String) = dao.delete(id)

    private fun NoteEntity.toNote() = Note(
        id = id,
        title = title,
        blocks = json.decodeFromString(blocksJson),
        createdAt = createdAt,
        updatedAt = updatedAt,
        lastOpenedAt = lastOpenedAt
    )

    private fun Note.toEntity(json: Json) = NoteEntity(
        id = id,
        title = title,
        blocksJson = json.encodeToString(blocks),
        createdAt = createdAt,
        updatedAt = updatedAt,
        lastOpenedAt = lastOpenedAt
    )
}
