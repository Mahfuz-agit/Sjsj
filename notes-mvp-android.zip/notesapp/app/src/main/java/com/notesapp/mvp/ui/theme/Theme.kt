package com.notesapp.mvp.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightScheme = lightColorScheme(
    primary = AppColors.accent,
    background = AppColors.surface,
    surface = AppColors.surface,
    onBackground = AppColors.content,
    onSurface = AppColors.content,
    outline = AppColors.divider,
)

/**
 * Light only for MVP, by deliberate PRD decision — this is not an oversight.
 * isSystemInDarkTheme() is intentionally ignored here; wire dark mode in
 * when it's actually scoped, don't half-support it.
 */
@Composable
fun NotesMvpTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightScheme,
        typography = AppTypography,
        content = content
    )
}
