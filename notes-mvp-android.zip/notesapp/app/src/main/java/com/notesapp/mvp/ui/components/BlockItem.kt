package com.notesapp.mvp.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.notesapp.mvp.ui.theme.AppColors
import com.notesapp.mvp.util.Block
import com.notesapp.mvp.util.BlockType

/**
 * Renders one block and reports two things upward: text changes, and
 * whether "/" was just typed as the first character (which triggers the
 * SlashMenu in the parent). Kept as a single composable per block — this is
 * the unit that LazyColumn virtualizes, so it needs to stay cheap to render.
 */
@Composable
fun BlockItem(
    block: Block,
    onTextChange: (String) -> Unit,
    onSlashTriggered: () -> Unit,
    onCheckedChange: () -> Unit,
    modifier: Modifier = Modifier
) {
    val textStyle: TextStyle = when (block.type) {
        BlockType.HEADING -> MaterialTheme.typography.titleLarge
        BlockType.CODE -> MaterialTheme.typography.bodyMedium.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        else -> MaterialTheme.typography.bodyLarge
    }.copy(
        color = AppColors.content,
        textDecoration = if (block.type == BlockType.CHECKBOX && block.checked) TextDecoration.LineThrough else TextDecoration.None
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (block.type == BlockType.CODE)
                    Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(AppColors.surfaceRecede)
                        .padding(8.dp)
                else Modifier.padding(vertical = 2.dp)
            )
    ) {
        if (block.type == BlockType.CHECKBOX) {
            Checkbox(checked = block.checked, onCheckedChange = { onCheckedChange() })
        }

        BasicTextField(
            value = block.text,
            onValueChange = { newText ->
                // "/" as the very first character of an otherwise-empty
                // block opens the insert menu instead of being typed.
                if (block.text.isEmpty() && newText == "/") {
                    onSlashTriggered()
                } else {
                    onTextChange(newText)
                }
            },
            textStyle = textStyle,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
