package com.notesapp.mvp.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.notesapp.mvp.ui.theme.AppColors
import com.notesapp.mvp.ui.viewmodel.SaveState

/**
 * No spinner, no "Saving..." blocking text. Per HIG's status principle
 * (indicators are transient, present only while true) and our own Restraint
 * principle: it appears briefly on save and disappears — it never demands
 * attention.
 *
 * Animation duration (300ms) sits in the short/purposeful motion range,
 * deliberately not copied from any specific platform's timing constant.
 */
@Composable
fun SaveIndicator(state: SaveState, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = state == SaveState.SAVED,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        Text(
            text = "Saved",
            color = AppColors.contentSecondary,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(8.dp)
        )
    }
}
