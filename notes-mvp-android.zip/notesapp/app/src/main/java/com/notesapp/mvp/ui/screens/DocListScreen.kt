package com.notesapp.mvp.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.notesapp.mvp.ui.theme.AppColors
import com.notesapp.mvp.ui.viewmodel.DocListViewModel

/**
 * Reached only via the menu icon on the editor screen — never the default
 * view on launch (that's always the last-opened doc, per the onboarding
 * flow decision). Search is instant, as-typed, no submit button, per HIG's
 * searching guidance and because it's genuinely free at this data scale
 * (local-only, no round trip).
 */
@Composable
fun DocListScreen(
    viewModel: DocListViewModel,
    onSelectNote: (String) -> Unit,
    onCreateNote: () -> Unit
) {
    val notes by viewModel.notes.collectAsState()
    var query by remember { mutableStateOf("") }

    Surface(color = AppColors.surface, modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {

            BasicTextField(
                value = query,
                onValueChange = {
                    query = it
                    viewModel.onSearchQueryChanged(it)
                },
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = AppColors.content),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            )
            if (query.isEmpty()) {
                Text(
                    text = "Search notes",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AppColors.contentSecondary
                )
            }

            Text(
                text = "+ New note",
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.accent,
                modifier = Modifier
                    .clickable { onCreateNote() }
                    .padding(vertical = 12.dp)
            )

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(notes, key = { it.id }) { note ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectNote(note.id) }
                            .padding(vertical = 10.dp)
                    ) {
                        Text(
                            text = note.title.ifBlank { "Untitled" },
                            style = MaterialTheme.typography.bodyLarge,
                            color = AppColors.content,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
