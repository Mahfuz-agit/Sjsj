package com.notesapp.mvp.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(note: NoteEntity)

    @Update
    suspend fun update(note: NoteEntity)

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getById(id: String): NoteEntity?

    /** Powers "open on the last-viewed doc" — zero navigation on relaunch. */
    @Query("SELECT * FROM notes ORDER BY lastOpenedAt DESC LIMIT 1")
    suspend fun getMostRecentlyOpened(): NoteEntity?

    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun getAll(): Flow<List<NoteEntity>>

    /**
     * Client-side search index for MVP: a plain LIKE query is sufficient at
     * small-notebook scale and keeps the search path simple (no separate
     * index to keep in sync). If note counts grow large enough that LIKE
     * scans become slow, upgrade to an FTS4 virtual table — do not add a
     * server-side search dependency, which is explicitly out of scope.
     */
    @Query("SELECT * FROM notes WHERE title LIKE '%' || :query || '%' OR blocksJson LIKE '%' || :query || '%' ORDER BY updatedAt DESC")
    fun search(query: String): Flow<List<NoteEntity>>

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun delete(id: String)
}
